﻿namespace Bnpparibas.Maw.HouseKeeping.Services
{
    public interface IHouseKeepingProcess
    {
        void RunHouseKeeping(string configurationFile, bool simulate, int timeoutInSeconds, int topCount);
    }
}