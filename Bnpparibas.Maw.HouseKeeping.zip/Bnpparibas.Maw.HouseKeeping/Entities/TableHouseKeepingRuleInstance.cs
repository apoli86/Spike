﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bnpparibas.Maw.HouseKeeping.Entities
{
    public class TableHouseKeepingRuleInstance
    {
        public DbTable Table { get; set; }

        public string FilterConditionOnTime { get; set; }
        public string AdditionalFilterCondition { get; set; }

        public IList<DeleteCommandMetaData> DeleteCommandMetaDataList { get; set; }

        public bool IsValid { get; set; }

        public string ErrorMessage { get; set; }
    }
}
