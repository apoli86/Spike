﻿namespace Bnpparibas.Maw.HouseKeeping.Entities.DbGraph.Dto
{
    public class DbTableDto
    {
        public string Schema { get; set; }
        public string Name { get; set; }

        public string PrimaryKeyType { get; set; }
        public string PrimaryKeyName { get; set; }
    }
}
