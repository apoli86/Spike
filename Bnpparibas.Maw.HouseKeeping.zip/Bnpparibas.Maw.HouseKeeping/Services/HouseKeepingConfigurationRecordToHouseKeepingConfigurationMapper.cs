﻿using Bnpparibas.Maw.HouseKeeping.Entities;
using Bnpparibas.Maw.HouseKeeping.Entities.Record;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace Bnpparibas.Maw.HouseKeeping.Services
{
    public class HouseKeepingConfigurationRecordToHouseKeepingConfigurationMapper : IHouseKeepingConfigurationRecordToHouseKeepingConfigurationMapper
    {
        private readonly Regex deleteWhereConditionPattern;

        public HouseKeepingConfigurationRecordToHouseKeepingConfigurationMapper()
        {
            deleteWhereConditionPattern = new Regex(@"(\w+)\s*([\<|\>|\<=|=])\s*\|(\d+\s+(years|months|days))\|");
        }

        public HouseKeepingConfiguration Map(HouseKeepingConfigurationRecord record)
        {
            if (record == null) throw new ArgumentNullException(nameof(record));

            var entity = new HouseKeepingConfiguration();

            entity.RuleList = new List<TableHouseKeepingRule>();

            foreach(var ruleRecord in record.Rules)
            {
                var rule = new TableHouseKeepingRule();

                rule.TableSchema = ruleRecord.TableSchema;
                rule.TableName = ruleRecord.TableName;
                rule.FilterConditionOnTime = BuildFilterExpressionOnTime(ruleRecord.DeleteWhereCondition);
                rule.AdditionalFilterCondition = new FilterExpression() { Expression = ruleRecord.AdditionalDeleteWhereCondition };

                entity.RuleList.Add(rule);
            }

            return entity;
        }

        private FilterExpressionOnTime BuildFilterExpressionOnTime(string expression)
        {
            if (expression == null) throw new ArgumentNullException(nameof(expression));

            Match match = deleteWhereConditionPattern.Match(expression);

            if (match.Success)
            {
                string columnName         = match.Groups[1].Value;
                string comparisonOperator = match.Groups[2].Value;
                string timeValue          = match.Groups[3].Value;

                return new FilterExpressionOnTime() {
                    ColumnName = columnName,
                    Operator   = comparisonOperator,
                    TimeValue  = timeValue
                };
            }

            return new FilterExpressionOnTime();
        }
    }
}
