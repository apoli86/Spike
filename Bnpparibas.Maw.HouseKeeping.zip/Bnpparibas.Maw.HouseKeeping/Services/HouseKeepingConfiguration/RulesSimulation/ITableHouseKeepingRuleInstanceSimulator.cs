﻿using Bnpparibas.Maw.HouseKeeping.Entities.HouseKeepingConfiguration;

namespace Bnpparibas.Maw.HouseKeeping.Services.HouseKeepingConfiguration.RulesSimulation
{
    public interface ITableHouseKeepingRuleInstanceSimulator
    {
        void SimulateTableHouseKeepingRuleInstance(TableHouseKeepingRuleInstance ruleInstance, int topCount = 1000);
    }
}