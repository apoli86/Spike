﻿using System;
using Microsoft.Practices.Unity;

namespace Bnpparibas.Maw.HouseKeeping.Unity
{
    public static class UnityExtensions
    {
        public static T Resolve<T>(this IUnityContainer container, params ResolverOverride[] overrides)
        {
            return (T)(container ?? throw new ArgumentNullException(nameof(container))).Resolve(typeof(T), null, overrides);
        }
    }
}
