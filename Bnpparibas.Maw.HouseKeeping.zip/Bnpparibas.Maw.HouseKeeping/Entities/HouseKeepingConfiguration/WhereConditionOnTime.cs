﻿namespace Bnpparibas.Maw.HouseKeeping.Entities.HouseKeepingConfiguration
{
    public class WhereConditionOnTime
    {
        public string ColumnName { get; set; }
        public string Operator { get; set; }
        public string TimeValue { get; set; }
    }
}
