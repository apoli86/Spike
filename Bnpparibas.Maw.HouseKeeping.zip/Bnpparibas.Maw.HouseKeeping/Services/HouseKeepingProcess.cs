﻿using Bnpparibas.Maw.HouseKeeping.DAL;
using Bnpparibas.Maw.HouseKeeping.Entities;
using Bnpparibas.Maw.HouseKeeping.Entities.Dto;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bnpparibas.Maw.HouseKeeping.Services
{
    public class HouseKeepingProcess : IHouseKeepingProcess
    {
        private readonly IContextFactory contextFactory;
        private readonly IDbGraphBuilder dbGraphBuilder;
        private readonly ISchemaDao schemaDao;
        private readonly IHouseKeepingConfigurationReader houseKeepingConfigurationReader;
        private readonly ITableHouseKeepingRuleManager ruleManager;
        private readonly ITableHouseKeepingRuleInstanceSimulator ruleInstanceSimulator;
        private readonly ITableHouseKeepingRuleInstanceExecutor  ruleInstanceExecutor;

        public HouseKeepingProcess(IContextFactory contextFactory, IDbGraphBuilder dbGraphBuilder, ISchemaDao schemaDao, IHouseKeepingConfigurationReader houseKeepingConfigurationReader, ITableHouseKeepingRuleManager ruleManager, ITableHouseKeepingRuleInstanceSimulator ruleInstanceSimulator, ITableHouseKeepingRuleInstanceExecutor ruleInstanceExecutor)
        {
            this.contextFactory = contextFactory;
            this.dbGraphBuilder = dbGraphBuilder;
            this.schemaDao = schemaDao;
            this.houseKeepingConfigurationReader = houseKeepingConfigurationReader;
            this.ruleManager = ruleManager;
            this.ruleInstanceSimulator = ruleInstanceSimulator;
            this.ruleInstanceExecutor = ruleInstanceExecutor;
        }

        public void RunHouseKeeping(string configurationFile, bool simulate, int timeoutInSeconds, int topCount)
        {
            if (string.IsNullOrEmpty(configurationFile)) throw new ArgumentNullException(nameof(configurationFile));
            if (timeoutInSeconds <= 0) throw new ArgumentException($"{nameof(timeoutInSeconds)} must be greater than 0");
            if (topCount <= 0) throw new ArgumentException($"{nameof(topCount)} must be greater than 0");

            HouseKeepingConfiguration houseKeepingConfiguration = ReadHouseKeepingConfiguration(configurationFile);

            DbGraph dbGraph = CreateDbGraph();

            IList<TableHouseKeepingRuleInstance> ruleInstanceList = CreateTableHouseKeepingRuleInstanceList(dbGraph, houseKeepingConfiguration);

            if (!simulate)
            {
                ExecuteTableHouseKeepingRuleInstances(ruleInstanceList, timeoutInSeconds, topCount);
            }
            else
            {
                SimulateTableHouseKeepingRuleInstances(ruleInstanceList, topCount);
            }
        }

        private HouseKeepingConfiguration ReadHouseKeepingConfiguration(string configurationFile)
        {
            if (!File.Exists(configurationFile))
            {
                throw new FileNotFoundException($"Could not found House Keeping configuration file: {configurationFile}");
            }

            var houseKeepingConfiguration = houseKeepingConfigurationReader.Read(File.ReadAllBytes(configurationFile));
            return houseKeepingConfiguration;
        }

        private IList<TableHouseKeepingRuleInstance> CreateTableHouseKeepingRuleInstanceList(DbGraph dbGraph, HouseKeepingConfiguration houseKeepingConfiguration)
        {
            var ruleInstanceList = ruleManager.CreateRuleInstances(houseKeepingConfiguration.RuleList, dbGraph);
            return ruleInstanceList;
        }

        private void ExecuteTableHouseKeepingRuleInstances(IList<TableHouseKeepingRuleInstance> ruleInstanceList, int timeoutInSeconds, int topCount)
        {
            foreach (TableHouseKeepingRuleInstance ruleInstance in ruleInstanceList)
            {
                ruleInstanceExecutor.ExecuteTableHouseKeepingRuleInstance(ruleInstance, timeoutInSeconds, topCount);
            }
        }

        private void SimulateTableHouseKeepingRuleInstances(IList<TableHouseKeepingRuleInstance> ruleInstanceList, int topCount)
        {
            foreach (TableHouseKeepingRuleInstance ruleInstance in ruleInstanceList)
            {
                ruleInstanceSimulator.SimulateTableHouseKeepingRuleInstance(ruleInstance, topCount);
            }
        }

        private DbGraph CreateDbGraph()
        {
            using (var context = contextFactory.CreateContext())
            {
                IList<DbTableDto> dbTableDtoList = schemaDao.GetAllTables(context);
                IList<DbForeignKeyDto> dbForeignKeyDtoList = schemaDao.GetAllForeignKeyList(context);

                return dbGraphBuilder.Build(dbTableDtoList, dbForeignKeyDtoList);
            };
        }
    }
}
