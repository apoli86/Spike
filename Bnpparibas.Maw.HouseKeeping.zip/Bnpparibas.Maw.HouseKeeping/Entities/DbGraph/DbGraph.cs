﻿using System.Collections.Generic;

namespace Bnpparibas.Maw.HouseKeeping.Entities.DbGraph
{
    public class DbGraph
    {
        public IList<DbTable> TableList { get; set; }
        public IDictionary<DbTable, IList<DbForeignKey>> ForeignKeyByParentDictionary { get; set; }
    }
}
