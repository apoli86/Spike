﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using Bnpparibas.Maw.HouseKeeping.Entities.HouseKeepingConfiguration;
using Bnpparibas.Maw.HouseKeeping.Entities.HouseKeepingConfiguration.Record;
using Newtonsoft.Json;

namespace Bnpparibas.Maw.HouseKeeping.Services.HouseKeepingConfiguration.ConfigurationImport
{
    public class HouseKeepingConfigurationReader : IHouseKeepingConfigurationReader
    {
        private readonly IHouseKeepingConfigurationRecordToHouseKeepingConfigurationMapper mapper;
        private readonly ITableHouseKeepingRuleValidator validator;

        public HouseKeepingConfigurationReader(IHouseKeepingConfigurationRecordToHouseKeepingConfigurationMapper mapper, ITableHouseKeepingRuleValidator validator)
        {
            if (mapper == null) throw new ArgumentNullException(nameof(mapper));
            if (validator == null) throw new ArgumentNullException(nameof(validator));

            this.mapper = mapper;
            this.validator = validator;
        }

        public Entities.HouseKeepingConfiguration.HouseKeepingConfiguration Read(byte[] content)
        {
            if (content == null) throw new ArgumentNullException(nameof(content));

            using (var r = new StreamReader(new MemoryStream(content)))
            {
                var json = r.ReadToEnd();
                var record = JsonConvert.DeserializeObject<HouseKeepingConfigurationRecord>(json);

                Entities.HouseKeepingConfiguration.HouseKeepingConfiguration configuration = mapper.Map(record);

                foreach (TableHouseKeepingRule rule in configuration.RuleList)
                {
                    IList<string> errorMessageList = validator.Validate(rule);

                    rule.IsValid = !errorMessageList.Any();
                    rule.ErrorMessage = string.Join("; ", errorMessageList);
                }

                return configuration;
            }
        }
    }
}
