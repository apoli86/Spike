﻿namespace Bnpparibas.Maw.HouseKeeping.Services
{
    public interface ILogService
    {
        void WriteInfo(string message);
    }
}