﻿using System;
using System.Collections.Generic;
using System.Linq;
using Bnpparibas.Maw.HouseKeeping.Entities.DbGraph;
using Bnpparibas.Maw.HouseKeeping.Entities.HouseKeepingConfiguration;

namespace Bnpparibas.Maw.HouseKeeping.Services.HouseKeepingConfiguration.RulesEvaluation
{
    public class TableHouseKeepingRuleManager : ITableHouseKeepingRuleManager
    {
        private readonly ISqlFilterConditionBuilder sqlFilterConditionBuilder;

        public TableHouseKeepingRuleManager(ISqlFilterConditionBuilder sqlFilterConditionBuilder)
        {
            if (sqlFilterConditionBuilder == null) throw new ArgumentNullException(nameof(sqlFilterConditionBuilder));
            this.sqlFilterConditionBuilder = sqlFilterConditionBuilder;
        }

        public IList<TableHouseKeepingRuleInstance> CreateRuleInstanceList(IList<TableHouseKeepingRule> houseKeepingRuleList, DbGraph dbGraph)
        {
            if (houseKeepingRuleList == null) throw new ArgumentNullException(nameof(houseKeepingRuleList));
            if (dbGraph == null) throw new ArgumentNullException(nameof(dbGraph));

            var ruleInstanceList = new List<TableHouseKeepingRuleInstance>();
            var tableHandledByRuleInstanceDictionary = new Dictionary<DbTable, TableHouseKeepingRuleInstance>();

            foreach(TableHouseKeepingRule rule in houseKeepingRuleList)
            {
                if (!rule.IsValid)
                {
                    continue;
                }

                var ruleInstance = CreateRuleInstance(rule, dbGraph);

                CheckIfAnotherRuleInstanceCoversOneOrMoreTable(tableHandledByRuleInstanceDictionary, ruleInstance);

                PopulateTableHandledByRuleInstanceDictionary(tableHandledByRuleInstanceDictionary, ruleInstance);

                ruleInstanceList.Add(ruleInstance);
            }

            return ruleInstanceList;
        }

        private void PopulateTableHandledByRuleInstanceDictionary(Dictionary<DbTable, TableHouseKeepingRuleInstance> tableHandledByRuleInstanceDictionary, TableHouseKeepingRuleInstance ruleInstance)
        {
            if (!tableHandledByRuleInstanceDictionary.ContainsKey(ruleInstance.Table))
            {
                tableHandledByRuleInstanceDictionary.Add(ruleInstance.Table, ruleInstance);
            }

            IList<DbTable> childrenTable = ruleInstance.DeleteCommandMetaDataList.Select(x => x.ChildTable).ToList();
            foreach (var childTable in childrenTable)
            {
                if (!tableHandledByRuleInstanceDictionary.ContainsKey(childTable))
                {
                    tableHandledByRuleInstanceDictionary.Add(childTable, ruleInstance);
                }
            }
        }

        private void CheckIfAnotherRuleInstanceCoversOneOrMoreTable(IDictionary<DbTable, TableHouseKeepingRuleInstance> tableHandledByRuleInstanceDictionary, TableHouseKeepingRuleInstance ruleInstance)
        {
            ruleInstance.ErrorMessage = string.Empty;
            if (tableHandledByRuleInstanceDictionary.ContainsKey(ruleInstance.Table))
            {
                ruleInstance.IsValid = false;
                var existingRuleInstance = tableHandledByRuleInstanceDictionary[ruleInstance.Table];
                ruleInstance.ErrorMessage = $"[{ruleInstance.Table.Schema}][{ruleInstance.Table.Name}] has already been covered by house keeping rule for table [{existingRuleInstance.Table.Schema}][{existingRuleInstance.Table.Name}]";
            }

            IList<DbTable> childrenTable = ruleInstance.DeleteCommandMetaDataList.Select(x => x.ChildTable).ToList();
            foreach (var childTable in childrenTable)
            {
                if (tableHandledByRuleInstanceDictionary.ContainsKey(childTable))
                {
                    ruleInstance.IsValid = false;
                    var existingRuleInstance = tableHandledByRuleInstanceDictionary[childTable];
                    ruleInstance.ErrorMessage += $";[{ruleInstance.Table.Schema}][{ruleInstance.Table.Name}] has already been covered by house keeping rule for table [{existingRuleInstance.Table.Schema}][{existingRuleInstance.Table.Name}]";
                }
            }
        }

        private TableHouseKeepingRuleInstance CreateRuleInstance(TableHouseKeepingRule houseKeepingRule, DbGraph dbGraph)
        {
            var tableSchema = houseKeepingRule.TableSchema;
            var tableName = houseKeepingRule.TableName;

            var table = dbGraph.TableList.FirstOrDefault(t => string.Equals(t.Schema, tableSchema, StringComparison.InvariantCultureIgnoreCase) && string.Equals(t.Name, tableName, StringComparison.InvariantCultureIgnoreCase));

            if (table == null)
            {
                throw new InvalidOperationException($"Database has no table [{tableSchema}].[{tableName}]");
            }

            var ruleInstance = new TableHouseKeepingRuleInstance();
            ruleInstance.Table = table;
            ruleInstance.DeleteCommandMetaDataList = new List<DeleteCommandMetaData>();
            ruleInstance.OriginalTimeValue = houseKeepingRule.WhereConditionOnTime?.TimeValue;
            ruleInstance.WhereConditionOnTime = sqlFilterConditionBuilder.BuildFilterCondition(houseKeepingRule.WhereConditionOnTime);
            ruleInstance.AdditionalWhereCondition = houseKeepingRule.AdditionalWhereCondition?.Expression;
            ruleInstance.IsValid = true;

            var toVisitStack = new Stack<DbTable>();
            var visitedList = new List<DbTable>();

            toVisitStack.Push(table);
            var foreignKeyDictionary = dbGraph.ForeignKeyByParentDictionary;

            var level = 0;
            while (toVisitStack.Any())
            {
                var currentTable = toVisitStack.Pop();
                var children = foreignKeyDictionary.ContainsKey(currentTable) ? foreignKeyDictionary[currentTable] : new List<DbForeignKey>();
                
                foreach(var foreignKey in children)
                {
                    if (visitedList.Contains(foreignKey.ChildTable))
                    {
                        continue;
                    }

                    var deleteCommandMetaData = new DeleteCommandMetaData();

                    deleteCommandMetaData.ParentTable = currentTable;
                    deleteCommandMetaData.ChildTable = foreignKey.ChildTable;
                    deleteCommandMetaData.ForeignKeyName = foreignKey.ForeignKeyName;
                    deleteCommandMetaData.Order = level;

                    ruleInstance.DeleteCommandMetaDataList.Add(deleteCommandMetaData);

                    toVisitStack.Push(foreignKey.ChildTable);
                    visitedList.Add(foreignKey.ChildTable);
                }

                level++;
            }

            return ruleInstance;
        }
    }
}
