﻿using Bnpparibas.Maw.HouseKeeping.Entities;
using Bnpparibas.Maw.HouseKeeping.Entities.Dto;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bnpparibas.Maw.HouseKeeping.Services
{
    public class DbGraphBuilder : IDbGraphBuilder
    {
        public DbGraph Build(IList<DbTableDto> tableDtoList, IList<DbForeignKeyDto> foreignKeyDtoList)
        {
            var tableDictionary = new Dictionary<string, DbTable>();
            var dbGraph = new DbGraph();

            dbGraph.TableList = new List<DbTable>();
            dbGraph.ForeignKeyByParentDictionary = new Dictionary<DbTable, IList<DbForeignKey>>();

            foreach(var tableDto in tableDtoList)
            {
                var table = new DbTable();
                table.Schema = tableDto.Schema;
                table.Name = tableDto.Name;
                table.PrimaryKeyName = tableDto.PrimaryKeyName;
                table.PrimaryKeyType = tableDto.PrimaryKeyType;

                dbGraph.TableList.Add(table);

                tableDictionary.Add($"[{table.Schema}].[{table.Name}]", table);
            }

            foreach (var foreignKeyDto in foreignKeyDtoList)
            {
                var foreignKey = new DbForeignKey();

                DbTable parentTable;
                DbTable childTable;

                string parentTableName = $"[{foreignKeyDto.ParentTableSchema}].[{foreignKeyDto.ParentTableName}]";
                if (!tableDictionary.TryGetValue(parentTableName, out parentTable))
                {
                    throw new InvalidOperationException($"Missing {parentTableName}");
                }

                string childTableName = $"[{foreignKeyDto.ForeignKeyTableSchema}].[{foreignKeyDto.ForeignKeyTableName}]";
                if (!tableDictionary.TryGetValue(childTableName, out childTable))
                {
                    throw new InvalidOperationException($"Missing {childTableName}");
                }

                foreignKey.ParentTable = parentTable;
                foreignKey.ChildTable = childTable;
                foreignKey.ForeignKeyName = foreignKeyDto.ForeignKeyColumn;

                IList<DbForeignKey> parentTableForeignKeyList;
                if (!dbGraph.ForeignKeyByParentDictionary.TryGetValue(parentTable, out parentTableForeignKeyList))
                {
                    parentTableForeignKeyList = new List<DbForeignKey>();
                    dbGraph.ForeignKeyByParentDictionary.Add(parentTable, parentTableForeignKeyList);
                }

                parentTableForeignKeyList.Add(foreignKey);
            }

            return dbGraph;
        }
    }
}
