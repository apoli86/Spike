﻿using Bnpparibas.Maw.HouseKeeping.Entities.HouseKeepingConfiguration;

namespace Bnpparibas.Maw.HouseKeeping.Services.HouseKeepingConfiguration.RulesEvaluation
{
    public interface ISqlFilterConditionBuilder
    {
        string BuildFilterCondition(WhereConditionOnTime whereCondition);
    }
}