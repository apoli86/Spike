﻿using Bnpparibas.Maw.HouseKeeping.DAL;
using Bnpparibas.Maw.HouseKeeping.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Practices.Unity;

namespace Bnpparibas.Maw.HouseKeeping
{
    public class UnityConfiguration
    {
        public IUnityContainer BuildUnityContainer()
        {
            IUnityContainer container = new UnityContainer();

            container.RegisterType<IHouseKeepingConfigurationRecordToHouseKeepingConfigurationMapper, HouseKeepingConfigurationRecordToHouseKeepingConfigurationMapper>();
            container.RegisterType<IHouseKeepingConfigurationReader, HouseKeepingConfigurationReader>();

            container.RegisterType<IConfigurationReader, ConfigurationReader>();
            container.RegisterType<IContextFactory, DapperContextFactory>();
            container.RegisterType<ISchemaDao, SchemaDao>();

            container.RegisterType<IDbGraphBuilder, DbGraphBuilder>();

            container.RegisterType<ILogService, LogService>();

            container.RegisterType<ISqlFilterConditionBuilder, SqlFilterConditionBuilder>();
            container.RegisterType<ITableHouseKeepingRuleManager, TableHouseKeepingRuleManager>();

            container.RegisterType<ITableHouseKeepingRuleInstanceSqlBuilder, TableHouseKeepingRuleInstanceSqlBuilder>();
            container.RegisterType<ITableHouseKeepingRuleInstanceExecutor, TableHouseKeepingRuleInstanceExecutor>();
            container.RegisterType<ITableHouseKeepingRuleInstanceSimulator, TableHouseKeepingRuleInstanceSimulator>();

            container.RegisterType<IHouseKeepingProcess, HouseKeepingProcess>();

            return container;
        }

    }
}
