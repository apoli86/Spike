﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bnpparibas.Maw.HouseKeeping.Entities
{
    public class DeleteCommandMetaData
    {
        public DbTable ParentTable { get; set; }
        public DbTable ChildTable { get; set; }
        public string  ForeignKeyName { get; set; }

        public int     Order { get; set; }
    }
}
