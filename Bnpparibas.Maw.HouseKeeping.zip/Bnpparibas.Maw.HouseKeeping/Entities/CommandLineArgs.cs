﻿using CommandLine;

namespace Bnpparibas.Maw.HouseKeeping.Entities
{
    public class CommandLineArgs
    {
        [Option('c', "config", Required=true, HelpText="House Keeping configuration file path")]
        public string HouseKeepingConfigurationFile { get; set; }

        [Option('t', "timeout", Required = false, Default = 60, HelpText = "Timeout in minutes for each delete command")]
        public int TimeoutInMinutes { get; set; }

        [Option('r', "rowcount", Required = false, Default = 1000, HelpText = "Rows to be processed by each delete command")]
        public int RowCount { get; set; }

        [Option('s', "simulate", Required = false, Default = false, HelpText = "Sql commands generated according to configuration will be printed only not executed")]
        public bool Simulate { get; set; }
    }
}
