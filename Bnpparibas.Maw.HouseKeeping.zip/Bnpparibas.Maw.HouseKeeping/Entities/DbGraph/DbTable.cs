﻿namespace Bnpparibas.Maw.HouseKeeping.Entities.DbGraph
{
    public class DbTable
    {
        public string Schema { get; set; }
        public string Name { get; set; }

        public string PrimaryKeyType { get; set; }
        public string PrimaryKeyName { get; set; }
    }
}
