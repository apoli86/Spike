﻿using System.Collections.Generic;
using Bnpparibas.Maw.HouseKeeping.Entities.HouseKeepingConfiguration;

namespace Bnpparibas.Maw.HouseKeeping.Services.HouseKeepingConfiguration.RulesProcess
{
    public interface ITableHouseKeepingRuleInstanceSqlBuilder
    {
        IList<ISqlStatement> BuildSqlStatementList(TableHouseKeepingRuleInstance ruleInstance, int topCount);
    }
}