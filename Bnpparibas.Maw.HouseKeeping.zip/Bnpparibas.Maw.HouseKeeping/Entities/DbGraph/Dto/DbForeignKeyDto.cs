﻿namespace Bnpparibas.Maw.HouseKeeping.Entities.DbGraph.Dto
{
    public class DbForeignKeyDto
    {
        public string ParentTableSchema     { get; set; }
        public string ParentTableName       { get; set; }
        public string ParentTableColumn     { get; set; }

        public string ForeignKeyTableSchema { get; set; }
        public string ForeignKeyTableName   { get; set; }
        public string ForeignKeyColumn      { get; set; }
    }
}
