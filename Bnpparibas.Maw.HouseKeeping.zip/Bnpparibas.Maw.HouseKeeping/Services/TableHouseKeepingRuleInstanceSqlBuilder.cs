﻿using Bnpparibas.Maw.HouseKeeping.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bnpparibas.Maw.HouseKeeping.Services
{
    public class TableHouseKeepingRuleInstanceSqlBuilder : ITableHouseKeepingRuleInstanceSqlBuilder
    {
        public IList<ISqlStatement> BuildSqlStatementList(TableHouseKeepingRuleInstance ruleInstance, int topCount)
        {
            if (ruleInstance == null) throw new ArgumentNullException(nameof(ruleInstance));

            IList<ISqlStatement> sqlStatementList = new List<ISqlStatement>();

            IList<DeleteCommandMetaData> deleteCommandMetaDataList = ruleInstance.DeleteCommandMetaDataList.OrderByDescending(x => x.Order).ToList();

            CreateTempTable createTempTable = BuildCreateTempTable(ruleInstance.Table, ruleInstance.FilterConditionOnTime, ruleInstance.AdditionalFilterCondition);
            sqlStatementList.Add(createTempTable);

            foreach(DeleteCommandMetaData deleteCommandMetaData in deleteCommandMetaDataList)
            {
                SelectCount selectCount = BuildSelectCount(ruleInstance.Table, deleteCommandMetaDataList, deleteCommandMetaData);
                DeleteCommand deleteCommand = BuildDeleteCommand(topCount, ruleInstance.Table, deleteCommandMetaDataList, deleteCommandMetaData);

                sqlStatementList.Add(selectCount);
                sqlStatementList.Add(deleteCommand);
            }

            SelectCount rootSelectCount = BuildSelectCount(ruleInstance.Table);
            DeleteCommand rootDeleteCommand = BuildDeleteCommand(topCount, ruleInstance.Table);

            sqlStatementList.Add(rootSelectCount);
            sqlStatementList.Add(rootDeleteCommand);

            DropTempTable dropTempTable = BuildDropTempTable(ruleInstance.Table);

            sqlStatementList.Add(dropTempTable);

            return sqlStatementList;
        }

        private CreateTempTable BuildCreateTempTable(DbTable table, string filterConditionOnTime, string additionalFilterCondition)
        {
            string tableName = BuildTableName(table);
            string tempTableName = $"#Tmp{BuildTableAlias(table)}";
            string whereCondition = string.IsNullOrWhiteSpace(additionalFilterCondition) ? $"{filterConditionOnTime}" : $"({filterConditionOnTime}) AND ({additionalFilterCondition})";

            string code = $@"
CREATE TABLE {tempTableName} (
    {table.PrimaryKeyName} {table.PrimaryKeyType} PRIMARY KEY
)

INSERT INTO {tempTableName} SELECT {table.PrimaryKeyName} FROM {tableName} WHERE {whereCondition} 
            ";

            return new CreateTempTable() { Table = tableName, SqlCode = code };
        }

        private DeleteCommand BuildDeleteCommand(int topCount, DbTable rootTable, IList<DeleteCommandMetaData> deleteCommandMetaDataList, DeleteCommandMetaData currentDeleteCommandMetaData)
        {
            DbTable parentTable = currentDeleteCommandMetaData.ParentTable;
            DbTable childTable = currentDeleteCommandMetaData.ChildTable;

            string tableName = BuildTableName(childTable);
            string tableAlias = BuildTableAlias(childTable);
            string code = $@"
DECLARE @AffectedRow AS BIGINT = 1

WHILE (@AffectedRow > 0)
BEGIN
    DELETE TOP ({topCount}) {tableAlias} FROM {tableName} {tableAlias} WITH(nolock) " + Environment.NewLine;
            while(currentDeleteCommandMetaData != null)
            {
                parentTable = currentDeleteCommandMetaData.ParentTable;
                childTable = currentDeleteCommandMetaData.ChildTable;

                if (parentTable == rootTable)
                {
                    string parentTableName = $"#Tmp{BuildTableAlias(rootTable)}";
                    string parentTableAlias = BuildTableAlias(rootTable);
                    code += $"      INNER JOIN {parentTableName} {parentTableAlias} WITH(nolock) ON {parentTableAlias}.{parentTable.PrimaryKeyName} = {tableAlias}.{currentDeleteCommandMetaData.ForeignKeyName} " + Environment.NewLine;
                }
                else
                {
                    string parentTableName = BuildTableName(parentTable);
                    string parentTableAlias = BuildTableAlias(parentTable);
                    code += $"      INNER JOIN {parentTableName} {parentTableAlias} WITH(nolock) ON {parentTableAlias}.{parentTable.PrimaryKeyName} = {tableAlias}.{currentDeleteCommandMetaData.ForeignKeyName} " + Environment.NewLine;
                }

                currentDeleteCommandMetaData = deleteCommandMetaDataList.SingleOrDefault(x => x.ChildTable == parentTable);
            }

            code += @"

    SET @AffectedRow = @@ROWCOUNT
END
";
            return new DeleteCommand() { Table = tableName, SqlCode = code };
        }

        private DeleteCommand BuildDeleteCommand(int topCount, DbTable rootTable)
        {
            string tableName = BuildTableName(rootTable);
            string tableAlias = BuildTableAlias(rootTable);
            string tempTableName = $"#Tmp{BuildTableAlias(rootTable)}";
            string tempTableNameAlias = $"Tmp{BuildTableAlias(rootTable)}";

            string code = $@"
DECLARE @AffectedRow AS BIGINT = 1

WHILE (@AffectedRow > 0)
BEGIN
    DELETE TOP ({topCount}) {tableAlias} FROM {tableName} {tableAlias} WITH(nolock) 
        INNER JOIN {tempTableName} {tempTableNameAlias} WITH(nolock) ON {tempTableNameAlias}.{rootTable.PrimaryKeyName} = {tableAlias}.{rootTable.PrimaryKeyName}

    SET @AffectedRow = @@ROWCOUNT

    DELETE TOP ({topCount}) {tempTableNameAlias} FROM {tempTableName} {tempTableNameAlias} WITH(nolock)
END
";
            return new DeleteCommand() { Table = tableName, SqlCode = code };
        }

        private SelectCount BuildSelectCount(DbTable rootTable, IList<DeleteCommandMetaData> deleteCommandMetaDataList, DeleteCommandMetaData currentDeleteCommandMetaData)
        {
            DbTable parentTable = currentDeleteCommandMetaData.ParentTable;
            DbTable childTable = currentDeleteCommandMetaData.ChildTable;

            string tableName = BuildTableName(childTable);
            string tableAlias = BuildTableAlias(childTable);
            string code = $"SELECT COUNT(*) FROM {tableName} {tableAlias} WITH(nolock) " + Environment.NewLine;

            while (currentDeleteCommandMetaData != null)
            {
                parentTable = currentDeleteCommandMetaData.ParentTable;
                childTable = currentDeleteCommandMetaData.ChildTable;

                if (parentTable == rootTable)
                {
                    string parentTableName = $"#Tmp{BuildTableAlias(rootTable)}";
                    string parentTableAlias = BuildTableAlias(rootTable);
                    code += $" INNER JOIN {parentTableName} {parentTableAlias} WITH(nolock) ON {parentTableAlias}.{parentTable.PrimaryKeyName} = {tableAlias}.{currentDeleteCommandMetaData.ForeignKeyName} " + Environment.NewLine;
                }
                else
                {
                    string parentTableName = BuildTableName(parentTable);
                    string parentTableAlias = BuildTableAlias(parentTable);
                    code += $" INNER JOIN {parentTableName} {parentTableAlias} WITH(nolock) ON {parentTableAlias}.{parentTable.PrimaryKeyName} = {tableAlias}.{currentDeleteCommandMetaData.ForeignKeyName} " + Environment.NewLine;
                }

                currentDeleteCommandMetaData = deleteCommandMetaDataList.SingleOrDefault(x => x.ChildTable == parentTable);
            }

            return new SelectCount() { Table = tableName, SqlCode = code };
        }

        private DropTempTable BuildDropTempTable(DbTable table)
        {
            string tableName = BuildTableName(table);
            string tempTableName = $"#Tmp{BuildTableAlias(table)}";
            
            string code = $@"
DROP TABLE {tempTableName}
            ";

            return new DropTempTable() { Table = tableName, SqlCode = code };
        }

        private SelectCount BuildSelectCount(DbTable rootTable)
        {
            string tempTableName = $"#Tmp{BuildTableAlias(rootTable)}";
            string tempTableNameAlias = BuildTableAlias(rootTable);
            string code = $"SELECT COUNT(*) FROM {tempTableName} {tempTableNameAlias} WITH(nolock)";

            return new SelectCount() { Table = BuildTableName(rootTable), SqlCode = code };
        }

        private string BuildTableName(DbTable table)
        {
            return $"[{table.Schema}].[{table.Name}]";
        }

        private string BuildTableAlias(DbTable table)
        {
            return $"{table.Schema}{table.Name}";
        }
    }
}
