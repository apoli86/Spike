﻿using System;

namespace Bnpparibas.Maw.HouseKeeping.DAL
{
    public class DapperContextFactory : IContextFactory
    {
        private readonly IConfigurationReader configurationReader;

        public DapperContextFactory(IConfigurationReader configurationReader)
        {
            if (configurationReader == null) throw new ArgumentNullException(nameof(configurationReader));

            this.configurationReader = configurationReader;
        }

        public IContext CreateContext()
        {
            return new DapperContext(configurationReader.ConnectionString);
        }
    }
}
