﻿using Bnpparibas.Maw.HouseKeeping.Entities;

namespace Bnpparibas.Maw.HouseKeeping.Services
{
    public interface ISqlFilterConditionBuilder
    {
        string BuildFilterCondition(FilterExpressionOnTime filterExpression);
    }
}