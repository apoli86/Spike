﻿using Bnpparibas.Maw.HouseKeeping.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bnpparibas.Maw.HouseKeeping.Services
{
    public class TableHouseKeepingRuleInstanceSimulator : ITableHouseKeepingRuleInstanceSimulator
    {
        private readonly ILogService logService;
        private readonly ITableHouseKeepingRuleInstanceSqlBuilder sqlBuilder;
        
        public TableHouseKeepingRuleInstanceSimulator(ILogService logService, ITableHouseKeepingRuleInstanceSqlBuilder sqlBuilder)
        {
            this.logService = logService;
            this.sqlBuilder = sqlBuilder;
        }

        public void SimulateTableHouseKeepingRuleInstance(TableHouseKeepingRuleInstance ruleInstance, int topCount = 1000)
        {
            if (ruleInstance == null) throw new ArgumentNullException(nameof(ruleInstance));
            if (topCount <= 0) throw new ArgumentException(nameof(topCount));

            IList<ISqlStatement> statementList = sqlBuilder.BuildSqlStatementList(ruleInstance, topCount);

            logService.WriteInfo($"-- Delete rows from '[{ruleInstance.Table.Schema}].[{ruleInstance.Table.Name}]' where '{ruleInstance.FilterConditionOnTime}'");

            foreach (ISqlStatement statement in statementList)
            {
                Print(statement);
            }

            logService.WriteInfo($"--");
            logService.WriteInfo($"--");
        }

        private void Print(ISqlStatement sqlStatement)
        {
            logService.WriteInfo($"-- {sqlStatement.Table}: {sqlStatement.GetType().Name}");
            logService.WriteInfo($"{sqlStatement.SqlCode}");
            logService.WriteInfo($"GO");
            logService.WriteInfo($"--{Environment.NewLine}");
        }
    }
}
