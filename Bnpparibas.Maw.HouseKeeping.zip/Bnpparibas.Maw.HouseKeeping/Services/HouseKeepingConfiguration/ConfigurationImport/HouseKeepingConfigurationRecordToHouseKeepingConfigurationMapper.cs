﻿using System;
using System.Collections.Generic;
using System.Text.RegularExpressions;
using Bnpparibas.Maw.HouseKeeping.Entities.HouseKeepingConfiguration;
using Bnpparibas.Maw.HouseKeeping.Entities.HouseKeepingConfiguration.Record;

namespace Bnpparibas.Maw.HouseKeeping.Services.HouseKeepingConfiguration.ConfigurationImport
{
    public class HouseKeepingConfigurationRecordToHouseKeepingConfigurationMapper : IHouseKeepingConfigurationRecordToHouseKeepingConfigurationMapper
    {
        private readonly Regex deleteWhereConditionPattern;

        public HouseKeepingConfigurationRecordToHouseKeepingConfigurationMapper()
        {
            deleteWhereConditionPattern = new Regex(@"(\w+)\s*([\<|\>|\<=|=])\s*\|(\d+\s+(years|months|days))\|");
        }

        public Entities.HouseKeepingConfiguration.HouseKeepingConfiguration Map(HouseKeepingConfigurationRecord record)
        {
            if (record == null) throw new ArgumentNullException(nameof(record));

            var entity = new Entities.HouseKeepingConfiguration.HouseKeepingConfiguration();

            entity.RuleList = new List<TableHouseKeepingRule>();

            foreach(var ruleRecord in record.Rules)
            {
                var rule = new TableHouseKeepingRule();

                rule.TableSchema = ruleRecord.TableSchema;
                rule.TableName = ruleRecord.TableName;
                rule.WhereConditionOnTime = BuildFilterExpressionOnTime(ruleRecord.DeleteWhereCondition);
                rule.AdditionalWhereCondition = new AdditionalWhereCondition() { Expression = ruleRecord.AdditionalDeleteWhereCondition };

                entity.RuleList.Add(rule);
            }

            return entity;
        }

        private WhereConditionOnTime BuildFilterExpressionOnTime(string expression)
        {
            if (expression == null) throw new ArgumentNullException(nameof(expression));

            var match = deleteWhereConditionPattern.Match(expression);

            if (match.Success)
            {
                var columnName         = match.Groups[1].Value;
                var comparisonOperator = match.Groups[2].Value;
                var timeValue          = match.Groups[3].Value;

                return new WhereConditionOnTime() {
                    ColumnName = columnName,
                    Operator   = comparisonOperator,
                    TimeValue  = timeValue
                };
            }

            return new WhereConditionOnTime();
        }
    }
}
