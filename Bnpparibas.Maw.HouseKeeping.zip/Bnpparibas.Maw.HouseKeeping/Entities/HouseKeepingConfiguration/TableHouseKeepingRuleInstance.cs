﻿using System.Collections.Generic;
using Bnpparibas.Maw.HouseKeeping.Entities.DbGraph;

namespace Bnpparibas.Maw.HouseKeeping.Entities.HouseKeepingConfiguration
{
    public class TableHouseKeepingRuleInstance
    {
        public DbTable Table { get; set; }

        public string OriginalTimeValue { get; set; }
        public string WhereConditionOnTime { get; set; }
        public string AdditionalWhereCondition { get; set; }

        public IList<DeleteCommandMetaData> DeleteCommandMetaDataList { get; set; }

        public bool IsValid { get; set; }

        public string ErrorMessage { get; set; }
    }
}
