﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bnpparibas.Maw.HouseKeeping.Entities
{
    public class TableHouseKeepingRule
    {
        public string TableSchema { get; set; }
        public string TableName { get; set; }

        public FilterExpressionOnTime FilterConditionOnTime { get; set; }
        public FilterExpression       AdditionalFilterCondition { get; set; }
    }
}
