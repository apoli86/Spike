﻿using Microsoft.Practices.Unity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bnpparibas.Maw.HouseKeeping
{
    public static class UnityExtensions
    {
        public static T Resolve<T>(this IUnityContainer container, params ResolverOverride[] overrides)
        {
            return (T)(container ?? throw new ArgumentNullException(nameof(container))).Resolve(typeof(T), null, overrides);
        }
    }
}
