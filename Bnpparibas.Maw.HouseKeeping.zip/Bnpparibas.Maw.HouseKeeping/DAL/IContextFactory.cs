﻿namespace Bnpparibas.Maw.HouseKeeping.DAL
{
    public interface IContextFactory
    {
        IContext CreateContext();
    }
}