﻿using Bnpparibas.Maw.HouseKeeping.DAL;
using Bnpparibas.Maw.HouseKeeping.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bnpparibas.Maw.HouseKeeping.Services
{
    public class TableHouseKeepingRuleInstanceExecutor : ITableHouseKeepingRuleInstanceExecutor
    {
        private readonly ILogService logService;
        private readonly ITableHouseKeepingRuleInstanceSqlBuilder sqlBuilder;
        private readonly IContextFactory contextFactory;

        public TableHouseKeepingRuleInstanceExecutor(ILogService logService, ITableHouseKeepingRuleInstanceSqlBuilder sqlBuilder, IContextFactory contextFactory)
        {
            this.logService = logService;
            this.sqlBuilder = sqlBuilder;
            this.contextFactory = contextFactory;
        }

        public void ExecuteTableHouseKeepingRuleInstance(TableHouseKeepingRuleInstance ruleInstance, int topCount = 1000, int timeoutInSeconds = 60)
        {
            if (ruleInstance == null) throw new ArgumentNullException(nameof(ruleInstance));
            if (topCount <= 0) throw new ArgumentException(nameof(topCount));
            if (timeoutInSeconds <= 0) throw new ArgumentException(nameof(timeoutInSeconds));

            IList<ISqlStatement> statementList = sqlBuilder.BuildSqlStatementList(ruleInstance, topCount);

            using(var context = contextFactory.CreateContext())
            {
                logService.WriteInfo($"[HouseKeeping] - Delete rows from '[{ruleInstance.Table.Schema}].[{ruleInstance.Table.Name}]' where '{ruleInstance.FilterConditionOnTime}'");

                foreach (ISqlStatement statement in statementList)
                {
                    Execute(statement, timeoutInSeconds, context);
                }

                context.Commit();
            }
        }

        private void Execute(ISqlStatement sqlStatement, int timeoutInSeconds, IContext context)
        {
            if (sqlStatement is SelectCount)
            {
                long count = context.ExecuteScalar<long>(sqlStatement.SqlCode);

                logService.WriteInfo($"[HouseKeeping] - Table {sqlStatement.Table}: {count} rows to delete");

                return;
            }

            if (sqlStatement is DeleteCommand)
            {
                context.Execute(sqlStatement.SqlCode, null, timeoutInSeconds);

                logService.WriteInfo($"[HouseKeeping] - Table {sqlStatement.Table}: rows deleted");

                return;
            }

            if (sqlStatement is CreateTempTable)
            {
                context.Execute(sqlStatement.SqlCode, null, timeoutInSeconds);

                logService.WriteInfo($"[HouseKeeping] - Table {sqlStatement.Table}: temporary table with Ids to delete created");

                return;
            }

            if (sqlStatement is DropTempTable)
            {
                context.Execute(sqlStatement.SqlCode, null, timeoutInSeconds);

                logService.WriteInfo($"[HouseKeeping] - Table {sqlStatement.Table}: temporary table dropped");

                return;
            }

            throw new InvalidOperationException($"Unhandled SqlStatement: {sqlStatement.GetType().Name}");
        }
    }
}
