﻿using System.Collections.Generic;
using Bnpparibas.Maw.HouseKeeping.Entities;
using Bnpparibas.Maw.HouseKeeping.Entities.Dto;

namespace Bnpparibas.Maw.HouseKeeping.Services
{
    public interface IDbGraphBuilder
    {
        DbGraph Build(IList<DbTableDto> tableDtoList, IList<DbForeignKeyDto> foreignKeyDtoList);
    }
}