﻿using Bnpparibas.Maw.HouseKeeping.Entities.DbGraph;

namespace Bnpparibas.Maw.HouseKeeping.Entities.HouseKeepingConfiguration
{
    public class DeleteCommandMetaData
    {
        public DbTable ParentTable { get; set; }
        public DbTable ChildTable { get; set; }
        public string  ForeignKeyName { get; set; }

        public int     Order { get; set; }
    }
}
