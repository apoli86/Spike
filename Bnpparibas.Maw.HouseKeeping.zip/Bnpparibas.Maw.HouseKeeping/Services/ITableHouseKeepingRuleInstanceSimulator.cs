﻿using Bnpparibas.Maw.HouseKeeping.Entities;

namespace Bnpparibas.Maw.HouseKeeping.Services
{
    public interface ITableHouseKeepingRuleInstanceSimulator
    {
        void SimulateTableHouseKeepingRuleInstance(TableHouseKeepingRuleInstance ruleInstance, int topCount = 1000);
    }
}