﻿using System;
using System.Collections.Generic;
using System.Linq;
using Bnpparibas.Maw.HouseKeeping.Entities.DbGraph;
using Bnpparibas.Maw.HouseKeeping.Entities.HouseKeepingConfiguration;

namespace Bnpparibas.Maw.HouseKeeping.Services.HouseKeepingConfiguration.RulesProcess
{
    public class TableHouseKeepingRuleInstanceSqlBuilder : ITableHouseKeepingRuleInstanceSqlBuilder
    {
        public IList<ISqlStatement> BuildSqlStatementList(TableHouseKeepingRuleInstance ruleInstance, int topCount)
        {
            if (ruleInstance == null) throw new ArgumentNullException(nameof(ruleInstance));

            IList<ISqlStatement> sqlStatementList = new List<ISqlStatement>();

            IList<DeleteCommandMetaData> deleteCommandMetaDataList = ruleInstance.DeleteCommandMetaDataList.OrderByDescending(x => x.Order).ToList();

            var createTempTable = BuildCreateTempTable(ruleInstance.Table, ruleInstance.WhereConditionOnTime, ruleInstance.AdditionalWhereCondition);
            sqlStatementList.Add(createTempTable);

            foreach(var deleteCommandMetaData in deleteCommandMetaDataList)
            {
                var selectCount = BuildSelectCount(ruleInstance.Table, deleteCommandMetaDataList, deleteCommandMetaData);
                var deleteCommand = BuildDeleteCommand(topCount, ruleInstance.Table, deleteCommandMetaDataList, deleteCommandMetaData);

                sqlStatementList.Add(selectCount);
                sqlStatementList.Add(deleteCommand);
            }

            var rootSelectCount = BuildSelectCount(ruleInstance.Table);
            var rootDeleteCommand = BuildDeleteCommand(topCount, ruleInstance.Table);

            sqlStatementList.Add(rootSelectCount);
            sqlStatementList.Add(rootDeleteCommand);

            var dropTempTable = BuildDropTempTable(ruleInstance.Table);

            sqlStatementList.Add(dropTempTable);

            return sqlStatementList;
        }

        private CreateTempTable BuildCreateTempTable(DbTable table, string filterConditionOnTime, string additionalFilterCondition)
        {
            var tableName = BuildTableName(table);
            var tempTableName = $"#Tmp{BuildTableAlias(table)}";
            var whereCondition = string.IsNullOrWhiteSpace(additionalFilterCondition) ? $"{filterConditionOnTime}" : $"({filterConditionOnTime}) AND ({additionalFilterCondition})";

            var code = $@"
CREATE TABLE {tempTableName} (
    {table.PrimaryKeyName} {table.PrimaryKeyType} PRIMARY KEY
)

INSERT INTO {tempTableName} SELECT {table.PrimaryKeyName} FROM {tableName} WHERE {whereCondition} 
            ";

            return new CreateTempTable() { Table = tableName, SqlCode = code };
        }

        private DeleteCommand BuildDeleteCommand(int topCount, DbTable rootTable, IList<DeleteCommandMetaData> deleteCommandMetaDataList, DeleteCommandMetaData currentDeleteCommandMetaData)
        {
            var parentTable = currentDeleteCommandMetaData.ParentTable;
            var childTable = currentDeleteCommandMetaData.ChildTable;

            var tableName = BuildTableName(childTable);
            var tableAlias = BuildTableAlias(childTable);
            var code = $@"
DECLARE @AffectedRow AS BIGINT = 1

WHILE (@AffectedRow > 0)
BEGIN
    DELETE TOP ({topCount}) {tableAlias} FROM {tableName} {tableAlias} WITH(nolock) " + Environment.NewLine;
            while(currentDeleteCommandMetaData != null)
            {
                parentTable = currentDeleteCommandMetaData.ParentTable;
                childTable = currentDeleteCommandMetaData.ChildTable;

                if (parentTable == rootTable)
                {
                    var parentTableName = $"#Tmp{BuildTableAlias(rootTable)}";
                    var parentTableAlias = BuildTableAlias(rootTable);
                    code += $"      INNER JOIN {parentTableName} {parentTableAlias} WITH(nolock) ON {parentTableAlias}.{parentTable.PrimaryKeyName} = {tableAlias}.{currentDeleteCommandMetaData.ForeignKeyName} " + Environment.NewLine;
                }
                else
                {
                    var parentTableName = BuildTableName(parentTable);
                    var parentTableAlias = BuildTableAlias(parentTable);
                    code += $"      INNER JOIN {parentTableName} {parentTableAlias} WITH(nolock) ON {parentTableAlias}.{parentTable.PrimaryKeyName} = {tableAlias}.{currentDeleteCommandMetaData.ForeignKeyName} " + Environment.NewLine;
                }

                currentDeleteCommandMetaData = deleteCommandMetaDataList.SingleOrDefault(x => x.ChildTable == parentTable);
            }

            code += @"

    SET @AffectedRow = @@ROWCOUNT
END
";
            return new DeleteCommand() { Table = tableName, SqlCode = code };
        }

        private DeleteCommand BuildDeleteCommand(int topCount, DbTable rootTable)
        {
            var tableName = BuildTableName(rootTable);
            var tableAlias = BuildTableAlias(rootTable);
            var tempTableName = $"#Tmp{BuildTableAlias(rootTable)}";
            var tempTableNameAlias = $"Tmp{BuildTableAlias(rootTable)}";

            var code = $@"
DECLARE @AffectedRow AS BIGINT = 1

WHILE (@AffectedRow > 0)
BEGIN
    DELETE TOP ({topCount}) {tableAlias} FROM {tableName} {tableAlias} WITH(nolock) 
        INNER JOIN {tempTableName} {tempTableNameAlias} WITH(nolock) ON {tempTableNameAlias}.{rootTable.PrimaryKeyName} = {tableAlias}.{rootTable.PrimaryKeyName}

    SET @AffectedRow = @@ROWCOUNT

    DELETE TOP ({topCount}) {tempTableNameAlias} FROM {tempTableName} {tempTableNameAlias} WITH(nolock)
END
";
            return new DeleteCommand() { Table = tableName, SqlCode = code };
        }

        private SelectCount BuildSelectCount(DbTable rootTable, IList<DeleteCommandMetaData> deleteCommandMetaDataList, DeleteCommandMetaData currentDeleteCommandMetaData)
        {
            var parentTable = currentDeleteCommandMetaData.ParentTable;
            var childTable = currentDeleteCommandMetaData.ChildTable;

            var tableName = BuildTableName(childTable);
            var tableAlias = BuildTableAlias(childTable);
            var code = $"SELECT COUNT(*) FROM {tableName} {tableAlias} WITH(nolock) " + Environment.NewLine;

            while (currentDeleteCommandMetaData != null)
            {
                parentTable = currentDeleteCommandMetaData.ParentTable;
                childTable = currentDeleteCommandMetaData.ChildTable;

                if (parentTable == rootTable)
                {
                    var parentTableName = $"#Tmp{BuildTableAlias(rootTable)}";
                    var parentTableAlias = BuildTableAlias(rootTable);
                    code += $" INNER JOIN {parentTableName} {parentTableAlias} WITH(nolock) ON {parentTableAlias}.{parentTable.PrimaryKeyName} = {tableAlias}.{currentDeleteCommandMetaData.ForeignKeyName} " + Environment.NewLine;
                }
                else
                {
                    var parentTableName = BuildTableName(parentTable);
                    var parentTableAlias = BuildTableAlias(parentTable);
                    code += $" INNER JOIN {parentTableName} {parentTableAlias} WITH(nolock) ON {parentTableAlias}.{parentTable.PrimaryKeyName} = {tableAlias}.{currentDeleteCommandMetaData.ForeignKeyName} " + Environment.NewLine;
                }

                currentDeleteCommandMetaData = deleteCommandMetaDataList.SingleOrDefault(x => x.ChildTable == parentTable);
            }

            return new SelectCount() { Table = tableName, SqlCode = code };
        }

        private DropTempTable BuildDropTempTable(DbTable table)
        {
            var tableName = BuildTableName(table);
            var tempTableName = $"#Tmp{BuildTableAlias(table)}";
            
            var code = $@"
DROP TABLE {tempTableName}
            ";

            return new DropTempTable() { Table = tableName, SqlCode = code };
        }

        private SelectCount BuildSelectCount(DbTable rootTable)
        {
            var tempTableName = $"#Tmp{BuildTableAlias(rootTable)}";
            var tempTableNameAlias = BuildTableAlias(rootTable);
            var code = $"SELECT COUNT(*) FROM {tempTableName} {tempTableNameAlias} WITH(nolock)";

            return new SelectCount() { Table = BuildTableName(rootTable), SqlCode = code };
        }

        private string BuildTableName(DbTable table)
        {
            return $"[{table.Schema}].[{table.Name}]";
        }

        private string BuildTableAlias(DbTable table)
        {
            return $"{table.Schema}{table.Name}";
        }
    }
}
