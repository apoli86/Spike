﻿namespace Bnpparibas.Maw.HouseKeeping.Entities.HouseKeepingConfiguration
{
    public interface ISqlStatement
    {
        string Table { get; set; }
        string SqlCode { get; set; }
    }

    public class DeleteCommand : ISqlStatement
    {
        public string Table { get; set; }
        public string SqlCode { get; set; }
    }

    public class SelectCount : ISqlStatement
    {
        public string Table { get; set; }
        public string SqlCode { get; set; }
    }

    public class CreateTempTable : ISqlStatement
    {
        public string Table { get; set; }
        public string SqlCode { get; set; }
    }

    public class DropTempTable : ISqlStatement
    {
        public string Table { get; set; }
        public string SqlCode { get; set; }
    }
}
