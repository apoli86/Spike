﻿using Bnpparibas.Maw.HouseKeeping.Entities.HouseKeepingConfiguration;

namespace Bnpparibas.Maw.HouseKeeping.Services.HouseKeepingConfiguration.RulesProcess
{
    public interface ITableHouseKeepingRuleInstanceExecutor
    {
        void ExecuteTableHouseKeepingRuleInstance(TableHouseKeepingRuleInstance ruleInstance, int topCount = 100, int timeoutInSeconds = 60);
    }
}