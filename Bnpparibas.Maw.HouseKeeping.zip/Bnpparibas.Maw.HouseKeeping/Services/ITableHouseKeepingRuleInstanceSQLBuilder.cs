﻿using System.Collections.Generic;
using Bnpparibas.Maw.HouseKeeping.Entities;

namespace Bnpparibas.Maw.HouseKeeping.Services
{
    public interface ITableHouseKeepingRuleInstanceSqlBuilder
    {
        IList<ISqlStatement> BuildSqlStatementList(TableHouseKeepingRuleInstance ruleInstance, int topCount);
    }
}