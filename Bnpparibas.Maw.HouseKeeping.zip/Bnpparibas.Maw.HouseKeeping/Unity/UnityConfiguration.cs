﻿using Bnpparibas.Maw.HouseKeeping.DAL;
using Bnpparibas.Maw.HouseKeeping.Services;
using Bnpparibas.Maw.HouseKeeping.Services.DatabaseMetaData;
using Bnpparibas.Maw.HouseKeeping.Services.HouseKeepingConfiguration.ConfigurationImport;
using Bnpparibas.Maw.HouseKeeping.Services.HouseKeepingConfiguration.RulesEvaluation;
using Bnpparibas.Maw.HouseKeeping.Services.HouseKeepingConfiguration.RulesProcess;
using Bnpparibas.Maw.HouseKeeping.Services.HouseKeepingConfiguration.RulesSimulation;
using Bnpparibas.Maw.HouseKeeping.Services.Log;
using Microsoft.Practices.Unity;

namespace Bnpparibas.Maw.HouseKeeping.Unity
{
    public class UnityConfiguration
    {
        public IUnityContainer BuildUnityContainer()
        {
            IUnityContainer container = new UnityContainer();

            container.RegisterType<IHouseKeepingConfigurationRecordToHouseKeepingConfigurationMapper, HouseKeepingConfigurationRecordToHouseKeepingConfigurationMapper>();
            container.RegisterType<ITableHouseKeepingRuleValidator, TableHouseKeepingRuleValidator>();
            container.RegisterType<IHouseKeepingConfigurationReader, HouseKeepingConfigurationReader>();

            container.RegisterType<IConfigurationReader, ConfigurationReader>();
            container.RegisterType<IContextFactory, DapperContextFactory>();
            container.RegisterType<ISchemaDao, SchemaDao>();

            container.RegisterType<IDbGraphBuilder, DbGraphBuilder>();

            container.RegisterType<ILogService, LogService>();

            container.RegisterType<ISqlFilterConditionBuilder, SqlFilterConditionBuilder>();
            container.RegisterType<ITableHouseKeepingRuleManager, TableHouseKeepingRuleManager>();

            container.RegisterType<ITableHouseKeepingRuleInstanceSqlBuilder, TableHouseKeepingRuleInstanceSqlBuilder>();
            container.RegisterType<ITableHouseKeepingRuleInstanceExecutor, TableHouseKeepingRuleInstanceExecutor>();
            container.RegisterType<ITableHouseKeepingRuleInstanceSimulator, TableHouseKeepingRuleInstanceSimulator>();

            container.RegisterType<IHouseKeepingProcess, HouseKeepingProcess>();

            return container;
        }

    }
}
