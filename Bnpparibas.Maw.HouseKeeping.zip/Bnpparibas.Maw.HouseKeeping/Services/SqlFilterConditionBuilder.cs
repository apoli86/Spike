﻿using Bnpparibas.Maw.HouseKeeping.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace Bnpparibas.Maw.HouseKeeping.Services
{
    public class SqlFilterConditionBuilder : ISqlFilterConditionBuilder
    {
        private Regex timeValuePattern;

        public SqlFilterConditionBuilder()
        {
            timeValuePattern = new Regex(@"(\d+)\s+(years|months|days)");
        }

        public string BuildFilterCondition(FilterExpressionOnTime filterExpression)
        {
            if (filterExpression == null) throw new ArgumentNullException("filterExpression");

            DateTime targetDate = ParseTimeValue(filterExpression.TimeValue?.ToLowerInvariant()?.Trim());

            return $"{filterExpression.ColumnName} {filterExpression.Operator} '{targetDate.ToString("yyyy-MM-dd")}'";
        }

        private DateTime ParseTimeValue(string timeValue)
        {
            Match match = timeValuePattern.Match(timeValue);

            if (!match.Success)
            {
                throw new InvalidOperationException($"Invalid time value: {timeValue}");
            }

            if (match.Groups.Count != 3)
            {
                throw new InvalidOperationException($"Invalid time value: {timeValue}");
            }

            int number = int.Parse(match.Groups[1].Value);
            string period = match.Groups[2].Value;

            DateTime targetDate = DateTime.Today;

            switch(period)
            {
                case "years":
                {
                    return DateTime.Today.AddYears(-number);
                }
                case "months":
                {
                    return DateTime.Today.AddMonths(-number);
                }
                case "days":
                {
                    return DateTime.Today.AddDays(-number);
                }
            }

            throw new InvalidOperationException($"Invalid time value: {timeValue}");
        }
    }
}
