﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using Bnpparibas.Maw.HouseKeeping.DAL;
using Bnpparibas.Maw.HouseKeeping.Entities.DbGraph;
using Bnpparibas.Maw.HouseKeeping.Entities.DbGraph.Dto;
using Bnpparibas.Maw.HouseKeeping.Entities.HouseKeepingConfiguration;
using Bnpparibas.Maw.HouseKeeping.Services.DatabaseMetaData;
using Bnpparibas.Maw.HouseKeeping.Services.HouseKeepingConfiguration.ConfigurationImport;
using Bnpparibas.Maw.HouseKeeping.Services.HouseKeepingConfiguration.RulesEvaluation;
using Bnpparibas.Maw.HouseKeeping.Services.HouseKeepingConfiguration.RulesProcess;
using Bnpparibas.Maw.HouseKeeping.Services.HouseKeepingConfiguration.RulesSimulation;
using Bnpparibas.Maw.HouseKeeping.Services.Log;

namespace Bnpparibas.Maw.HouseKeeping.Services
{
    public class HouseKeepingProcess : IHouseKeepingProcess
    {
        private readonly ILogService logService;
        private readonly IConfigurationReader configurationReader;
        private readonly IContextFactory contextFactory;
        private readonly IDbGraphBuilder dbGraphBuilder;
        private readonly ISchemaDao schemaDao;
        private readonly IHouseKeepingConfigurationReader houseKeepingConfigurationReader;
        private readonly ITableHouseKeepingRuleManager ruleManager;
        private readonly ITableHouseKeepingRuleInstanceSimulator ruleInstanceSimulator;
        private readonly ITableHouseKeepingRuleInstanceExecutor  ruleInstanceExecutor;

        public HouseKeepingProcess(ILogService logService, IContextFactory contextFactory, IDbGraphBuilder dbGraphBuilder, ISchemaDao schemaDao, IHouseKeepingConfigurationReader houseKeepingConfigurationReader, ITableHouseKeepingRuleManager ruleManager, ITableHouseKeepingRuleInstanceSimulator ruleInstanceSimulator, ITableHouseKeepingRuleInstanceExecutor ruleInstanceExecutor, IConfigurationReader configurationReader)
        {
            this.logService = logService;
            this.contextFactory = contextFactory;
            this.dbGraphBuilder = dbGraphBuilder;
            this.schemaDao = schemaDao;
            this.houseKeepingConfigurationReader = houseKeepingConfigurationReader;
            this.ruleManager = ruleManager;
            this.ruleInstanceSimulator = ruleInstanceSimulator;
            this.ruleInstanceExecutor = ruleInstanceExecutor;
            this.configurationReader = configurationReader;
        }

        public void RunHouseKeeping(string configurationFile, bool simulate, int timeoutInSeconds, int topCount)
        {
            if (string.IsNullOrEmpty(configurationFile)) throw new ArgumentNullException(nameof(configurationFile));
            if (timeoutInSeconds <= 0) throw new ArgumentException($"{nameof(timeoutInSeconds)} must be greater than 0");
            if (topCount <= 0) throw new ArgumentException($"{nameof(topCount)} must be greater than 0");

            logService.WriteInfo("[Step 01]: House Keeping Configuration reading");
            Entities.HouseKeepingConfiguration.HouseKeepingConfiguration houseKeepingConfiguration = ReadHouseKeepingConfiguration(configurationFile);
            logService.WriteInfo("--");

            logService.WriteInfo("[Step 02]: Database meta data retrieving");
            var dbGraph = CreateDbGraph();
            logService.WriteInfo("--");

            logService.WriteInfo("[Step 03]: House Keeping Rules processing");
            IList<TableHouseKeepingRuleInstance> ruleInstanceList = CreateTableHouseKeepingRuleInstanceList(dbGraph, houseKeepingConfiguration);

            if (!simulate)
            {
                ExecuteTableHouseKeepingRuleInstances(ruleInstanceList, timeoutInSeconds, topCount);
            }
            else
            {
                SimulateTableHouseKeepingRuleInstances(ruleInstanceList, topCount);
            }
        }

        private Entities.HouseKeepingConfiguration.HouseKeepingConfiguration ReadHouseKeepingConfiguration(string configurationFile)
        {
            if (!File.Exists(configurationFile))
            {
                throw new FileNotFoundException($"Could not found House Keeping configuration file: {configurationFile}");
            }

            byte[] content = File.ReadAllBytes(configurationFile);
            var houseKeepingConfiguration = houseKeepingConfigurationReader.Read(content);

            logService.WriteInfo($"\t'{configurationFile}' read: {houseKeepingConfiguration.RuleList.Count} House Keeping Rules found.");

            return houseKeepingConfiguration;
        }

        private IList<TableHouseKeepingRuleInstance> CreateTableHouseKeepingRuleInstanceList(DbGraph dbGraph, Entities.HouseKeepingConfiguration.HouseKeepingConfiguration houseKeepingConfiguration)
        {
            IList<TableHouseKeepingRule> invalidRuleList =
                houseKeepingConfiguration.RuleList.Where(r => !r.IsValid).ToList();

            if (invalidRuleList.Any())
            {
                logService.WriteInfo($"{invalidRuleList.Count} invalid House Keeping Rule found that will be skipped: ");
                foreach (TableHouseKeepingRule invalidRule in invalidRuleList)
                {
                    logService.WriteInfo($"- invalid house keeping rule for table [{invalidRule.TableSchema}][{invalidRule.TableName}]: {invalidRule.ErrorMessage}");
                }
            }

            IList<TableHouseKeepingRuleInstance> ruleInstanceList = ruleManager.CreateRuleInstanceList(houseKeepingConfiguration.RuleList, dbGraph);
            return ruleInstanceList;
        }

        private void ExecuteTableHouseKeepingRuleInstances(IList<TableHouseKeepingRuleInstance> ruleInstanceList, int timeoutInSeconds, int topCount)
        {
            TimeSpan timeout = TimeSpan.FromSeconds(timeoutInSeconds);

            logService.WriteInfo($"\t{ruleInstanceList.Count} House Keeping Rule will be processed");
            logService.WriteInfo($"\t- timeout in minutes for each sql statement: {timeout.TotalMinutes}");
            logService.WriteInfo($"\t- top value for delete statements: {topCount}");

            foreach (TableHouseKeepingRuleInstance ruleInstance in ruleInstanceList)
            {
                try
                {
                    ruleInstanceExecutor.ExecuteTableHouseKeepingRuleInstance(ruleInstance, timeoutInSeconds, topCount);
                }
                catch(Exception e)
                {
                    logService.WriteError(e.Message);
                }
            }
        }

        private void SimulateTableHouseKeepingRuleInstances(IList<TableHouseKeepingRuleInstance> ruleInstanceList, int topCount)
        {
            foreach (var ruleInstance in ruleInstanceList)
            {
                try
                {
                    ruleInstanceSimulator.SimulateTableHouseKeepingRuleInstance(ruleInstance, topCount);
                }
                catch (Exception e)
                {
                    logService.WriteError(e.Message);
                }
            }
        }

        private DbGraph CreateDbGraph()
        {
            logService.WriteInfo($"\tRetrieving tables meta data and foreign key from database");
            logService.WriteInfo($"\tConnection string: '{configurationReader.ConnectionString}'");

            var watch = System.Diagnostics.Stopwatch.StartNew();

            using (IContext context = contextFactory.CreateContext())
            {
                IList<DbTableDto> dbTableDtoList = schemaDao.GetAllTables(context);
                IList<DbForeignKeyDto> dbForeignKeyDtoList = schemaDao.GetAllForeignKeyList(context);

                DbGraph dbGraph = dbGraphBuilder.Build(dbTableDtoList, dbForeignKeyDtoList);

                watch.Stop();

                logService.WriteInfo($"\t{dbGraph.TableList.Count} tables found");
                logService.WriteInfo($"\t{dbGraph.ForeignKeyByParentDictionary.Count} foreign keys found");
                logService.WriteInfo($"\tElapsed time: {watch.Elapsed.TotalSeconds} seconds");

                return dbGraph;
            };
        }
    }
}

