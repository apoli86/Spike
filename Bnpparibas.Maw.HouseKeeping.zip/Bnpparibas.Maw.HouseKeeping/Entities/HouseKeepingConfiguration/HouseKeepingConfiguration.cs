﻿using System.Collections.Generic;

namespace Bnpparibas.Maw.HouseKeeping.Entities.HouseKeepingConfiguration
{
    public class HouseKeepingConfiguration
    {
        public IList<TableHouseKeepingRule> RuleList { get; set; }
    }
}
