﻿using Bnpparibas.Maw.HouseKeeping.Entities;

namespace Bnpparibas.Maw.HouseKeeping.Services
{
    public interface ITableHouseKeepingRuleInstanceExecutor
    {
        void ExecuteTableHouseKeepingRuleInstance(TableHouseKeepingRuleInstance ruleInstance, int topCount = 100, int timeoutInSeconds = 60);
    }
}