﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bnpparibas.Maw.HouseKeeping.Entities
{
    public class DbGraph
    {
        public IList<DbTable> TableList { get; set; }
        public IDictionary<DbTable, IList<DbForeignKey>> ForeignKeyByParentDictionary { get; set; }
    }
}
