﻿using System;
using Bnpparibas.Maw.HouseKeeping.Entities;
using Bnpparibas.Maw.HouseKeeping.Services;
using Bnpparibas.Maw.HouseKeeping.Unity;
using CommandLine;

namespace Bnpparibas.Maw.HouseKeeping
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                var unityContainer = new UnityConfiguration().BuildUnityContainer();

                var commandLineArgs = ParseCommandLineArgs(args);

                var houseKeepingProcess = unityContainer.Resolve<IHouseKeepingProcess>();

                var houseKeepingConfigurationFile = commandLineArgs.HouseKeepingConfigurationFile;
                var simulate = commandLineArgs.Simulate;
                var timeoutInSeconds = (int) TimeSpan.FromMinutes(commandLineArgs.TimeoutInMinutes).TotalSeconds;
                var rowCount = commandLineArgs.RowCount;

                houseKeepingProcess.RunHouseKeeping(
                    houseKeepingConfigurationFile,
                    simulate,
                    timeoutInSeconds,
                    rowCount);
            }
            catch(Exception e)
            {
                Console.WriteLine(e.Message);

                Environment.Exit(-1);
            }

            Environment.Exit(0);
        }

        private static CommandLineArgs ParseCommandLineArgs(string[] args)
        {
            var parsedCmdArgs = Parser.Default.ParseArguments<CommandLineArgs>(args);

            parsedCmdArgs.WithNotParsed(errors => throw new InvalidOperationException(string.Join(";", errors)));

            var commandLineArgs = parsedCmdArgs.MapResult(t => t, t => new CommandLineArgs());

            return commandLineArgs;
        }
    }
}
