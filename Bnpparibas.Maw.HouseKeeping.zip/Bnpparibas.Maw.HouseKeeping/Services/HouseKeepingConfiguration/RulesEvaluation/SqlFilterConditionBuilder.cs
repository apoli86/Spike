﻿using System;
using System.Text.RegularExpressions;
using Bnpparibas.Maw.HouseKeeping.Entities.HouseKeepingConfiguration;

namespace Bnpparibas.Maw.HouseKeeping.Services.HouseKeepingConfiguration.RulesEvaluation
{
    public class SqlFilterConditionBuilder : ISqlFilterConditionBuilder
    {
        private readonly Regex timeValuePattern;

        public SqlFilterConditionBuilder()
        {
            timeValuePattern = new Regex(@"(\d+)\s+(years|months|days)");
        }

        public string BuildFilterCondition(WhereConditionOnTime whereCondition)
        {
            if (whereCondition == null) throw new ArgumentNullException("whereCondition");

            var targetDate = ParseTimeValue(whereCondition.TimeValue?.ToLowerInvariant()?.Trim());

            return $"{whereCondition.ColumnName} {whereCondition.Operator} '{targetDate.ToString("yyyy-MM-dd")}'";
        }

        private DateTime ParseTimeValue(string timeValue)
        {
            var match = timeValuePattern.Match(timeValue);

            if (!match.Success)
            {
                throw new InvalidOperationException($"Invalid time value: {timeValue}");
            }

            if (match.Groups.Count != 3)
            {
                throw new InvalidOperationException($"Invalid time value: {timeValue}");
            }

            var number = int.Parse(match.Groups[1].Value);
            var period = match.Groups[2].Value;

            var targetDate = DateTime.Today;

            switch(period)
            {
                case "years":
                {
                    return DateTime.Today.AddYears(-number);
                }
                case "months":
                {
                    return DateTime.Today.AddMonths(-number);
                }
                case "days":
                {
                    return DateTime.Today.AddDays(-number);
                }
            }

            throw new InvalidOperationException($"Invalid time value: {timeValue}");
        }
    }
}
