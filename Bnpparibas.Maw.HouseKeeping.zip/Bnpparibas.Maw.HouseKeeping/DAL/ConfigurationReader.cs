﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bnpparibas.Maw.HouseKeeping.DAL
{
    public class ConfigurationReader : IConfigurationReader
    {
        public const string connectionStringKey = "Bnpparibas.HouseKeeping.ConnectionString";

        private string connectionString;

        public string ConnectionString
        {
            get
            {
                if (connectionString == null)
                {
                    this.connectionString = ReadConnectionStringKeyValue(connectionStringKey);
                }

                return connectionString;
            }
        }

        private string ReadAppSettingKeyValue(string key)
        {
            string appsettingKey = ConfigurationManager.AppSettings.AllKeys.SingleOrDefault(appKey => string.Equals(appKey, key, StringComparison.InvariantCultureIgnoreCase));
            
            if (appsettingKey == null)
            {
                throw new InvalidOperationException($"Missing AppSettings key: {key}");
            }

            return ConfigurationManager.AppSettings[key];
        }

        private string ReadConnectionStringKeyValue(string key)
        {
            var connectionString = ConfigurationManager.ConnectionStrings[key];

            if (connectionString == null)
            {
                throw new InvalidOperationException($"Missing ConnectionString with name: {key}");
            }

            return connectionString.ConnectionString;
        }
    }
}
