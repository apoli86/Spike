﻿using System;

namespace Bnpparibas.Maw.HouseKeeping.Services.Log
{
    public class LogService : ILogService
    {
        public void WriteInfo(string message)
        {
            Console.WriteLine("[INFO] " + message);
        }

        public void WriteError(string message)
        {
            Console.WriteLine("[ERR ] " + message);
        }
    }
}
