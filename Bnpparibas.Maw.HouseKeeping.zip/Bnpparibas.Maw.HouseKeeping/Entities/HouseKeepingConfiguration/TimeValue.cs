﻿namespace Bnpparibas.Maw.HouseKeeping.Entities.HouseKeepingConfiguration
{
    class TimeValue
    {
    }
}
