﻿using System;
using Bnpparibas.Maw.HouseKeeping.Entities.HouseKeepingConfiguration;
using Bnpparibas.Maw.HouseKeeping.Services.HouseKeepingConfiguration.RulesProcess;
using Bnpparibas.Maw.HouseKeeping.Services.Log;

namespace Bnpparibas.Maw.HouseKeeping.Services.HouseKeepingConfiguration.RulesSimulation
{
    public class TableHouseKeepingRuleInstanceSimulator : ITableHouseKeepingRuleInstanceSimulator
    {
        private readonly ILogService logService;
        private readonly ITableHouseKeepingRuleInstanceSqlBuilder sqlBuilder;
        
        public TableHouseKeepingRuleInstanceSimulator(ILogService logService, ITableHouseKeepingRuleInstanceSqlBuilder sqlBuilder)
        {
            this.logService = logService;
            this.sqlBuilder = sqlBuilder;
        }

        public void SimulateTableHouseKeepingRuleInstance(TableHouseKeepingRuleInstance ruleInstance, int topCount = 1000)
        {
            if (ruleInstance == null) throw new ArgumentNullException(nameof(ruleInstance));
            if (topCount <= 0) throw new ArgumentException(nameof(topCount));

            var statementList = sqlBuilder.BuildSqlStatementList(ruleInstance, topCount);

            logService.WriteInfo($"-- Delete rows from '[{ruleInstance.Table.Schema}].[{ruleInstance.Table.Name}]' where '{ruleInstance.WhereConditionOnTime}'");

            foreach (var statement in statementList)
            {
                Print(statement);
            }

            logService.WriteInfo($"--");
            logService.WriteInfo($"--");
        }

        private void Print(ISqlStatement sqlStatement)
        {
            logService.WriteInfo($"-- {sqlStatement.Table}: {sqlStatement.GetType().Name}");
            logService.WriteInfo($"{sqlStatement.SqlCode}");
            logService.WriteInfo($"GO");
            logService.WriteInfo($"--{Environment.NewLine}");
        }
    }
}
