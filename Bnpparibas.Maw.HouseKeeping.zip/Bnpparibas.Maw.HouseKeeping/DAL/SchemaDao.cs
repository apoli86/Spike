﻿using System;
using System.Collections.Generic;
using Bnpparibas.Maw.HouseKeeping.Entities.DbGraph.Dto;

namespace Bnpparibas.Maw.HouseKeeping.DAL
{
    public class SchemaDao : ISchemaDao
    {
        public IList<DbTableDto> GetAllTables(IContext context)
        {
            if (context == null) throw new ArgumentNullException(nameof(context));

            var query = @"
SELECT 
        keys.table_schema as [Schema], 
        keys.table_name   as [Name], 
        keys.column_name  as [PrimaryKeyName],
        col.data_type     as [PrimaryKeyType]
FROM    INFORMATION_SCHEMA.KEY_COLUMN_USAGE keys
        INNER JOIN INFORMATION_SCHEMA.TABLE_CONSTRAINTS CONS 
            ON     cons.TABLE_SCHEMA    = keys.TABLE_SCHEMA 
               AND cons.TABLE_NAME      = keys.TABLE_NAME 
               AND cons.CONSTRAINT_NAME = keys.CONSTRAINT_NAME
        INNER JOIN INFORMATION_SCHEMA.COLUMNS col 
	        ON     keys.TABLE_SCHEMA    = col.TABLE_SCHEMA
	           AND keys.TABLE_NAME      = col.TABLE_NAME
	           AND keys.COLUMN_NAME     = col.COLUMN_NAME
WHERE cons.CONSTRAINT_TYPE = 'PRIMARY KEY'
ORDER BY keys.table_schema, keys.table_name
";

            return context.Query<DbTableDto>(query);
        }

        public IList<DbForeignKeyDto> GetAllForeignKeyList(IContext context)
        {
            if (context == null) throw new ArgumentNullException(nameof(context));

            var query = @"
SELECT
	 KCU2.TABLE_SCHEMA AS [ParentTableSchema]
    ,KCU2.TABLE_NAME   AS [ParentTableName] 
    ,KCU2.COLUMN_NAME  AS [ParentTableColumn] 
    ,KCU1.TABLE_SCHEMA AS [ForeignKeyTableSchema] 
    ,KCU1.TABLE_NAME   AS [ForeignKeyTableName] 
    ,KCU1.COLUMN_NAME  AS [ForeignKeyColumn]
FROM INFORMATION_SCHEMA.REFERENTIAL_CONSTRAINTS AS RC 

INNER JOIN INFORMATION_SCHEMA.KEY_COLUMN_USAGE AS KCU1 
    ON KCU1.CONSTRAINT_CATALOG = RC.CONSTRAINT_CATALOG  
    AND KCU1.CONSTRAINT_SCHEMA = RC.CONSTRAINT_SCHEMA 
    AND KCU1.CONSTRAINT_NAME = RC.CONSTRAINT_NAME 

INNER JOIN INFORMATION_SCHEMA.KEY_COLUMN_USAGE AS KCU2 
    ON KCU2.CONSTRAINT_CATALOG = RC.UNIQUE_CONSTRAINT_CATALOG  
    AND KCU2.CONSTRAINT_SCHEMA = RC.UNIQUE_CONSTRAINT_SCHEMA 
    AND KCU2.CONSTRAINT_NAME = RC.UNIQUE_CONSTRAINT_NAME 
    AND KCU2.ORDINAL_POSITION = KCU1.ORDINAL_POSITION
ORDER BY [ParentTableSchema], [ParentTableName], [ForeignKeyTableSchema], [ForeignKeyTableName]

";
            return context.Query<DbForeignKeyDto>(query);
        }
    }
}
