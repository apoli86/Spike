﻿using System.Collections.Generic;
using Bnpparibas.Maw.HouseKeeping.Entities.DbGraph;
using Bnpparibas.Maw.HouseKeeping.Entities.DbGraph.Dto;

namespace Bnpparibas.Maw.HouseKeeping.Services.DatabaseMetaData
{
    public interface IDbGraphBuilder
    {
        DbGraph Build(IList<DbTableDto> tableDtoList, IList<DbForeignKeyDto> foreignKeyDtoList);
    }
}