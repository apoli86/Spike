﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bnpparibas.Maw.HouseKeeping.Entities
{
    public class DbTable
    {
        public string Schema { get; set; }
        public string Name { get; set; }

        public string PrimaryKeyType { get; set; }
        public string PrimaryKeyName { get; set; }
    }
}
