﻿namespace Bnpparibas.Maw.HouseKeeping.Services.Log
{
    public interface ILogService
    {
        void WriteInfo(string message);
        void WriteError(string message);
    }
}