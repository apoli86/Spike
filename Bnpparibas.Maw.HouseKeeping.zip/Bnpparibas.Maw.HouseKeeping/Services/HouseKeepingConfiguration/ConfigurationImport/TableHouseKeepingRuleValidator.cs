﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Bnpparibas.Maw.HouseKeeping.Entities.HouseKeepingConfiguration;

namespace Bnpparibas.Maw.HouseKeeping.Services.HouseKeepingConfiguration.ConfigurationImport
{
    public class TableHouseKeepingRuleValidator : ITableHouseKeepingRuleValidator
    {
        public IList<string> Validate(TableHouseKeepingRule rule)
        {
            if (rule == null) throw new ArgumentNullException(nameof(rule));

            IList<string> errorMessageList = new List<string>();

            if (string.IsNullOrWhiteSpace(rule.TableSchema))
            {
                errorMessageList.Add($"{nameof(rule.TableSchema)} cannot be null");
            }
            if (string.IsNullOrWhiteSpace(rule.TableName))
            {
                errorMessageList.Add($"{nameof(rule.TableName)} cannot be null");
            }
            if (rule.WhereConditionOnTime == null)
            {
                errorMessageList.Add($"{nameof(rule.WhereConditionOnTime)} cannot be null");
            }
            if (rule.WhereConditionOnTime != null && string.IsNullOrWhiteSpace(rule.WhereConditionOnTime.ColumnName))
            {
                errorMessageList.Add($"{nameof(rule.WhereConditionOnTime)}.{nameof(rule.WhereConditionOnTime.ColumnName)} cannot be null");
            }
            if (rule.WhereConditionOnTime != null && string.IsNullOrWhiteSpace(rule.WhereConditionOnTime.Operator))
            {
                errorMessageList.Add($"{nameof(rule.WhereConditionOnTime)}.{nameof(rule.WhereConditionOnTime.Operator)} cannot be null");
            }
            if (rule.WhereConditionOnTime != null && string.IsNullOrWhiteSpace(rule.WhereConditionOnTime.TimeValue))
            {
                errorMessageList.Add($"{nameof(rule.WhereConditionOnTime)}.{nameof(rule.WhereConditionOnTime.TimeValue)} cannot be null");
            }

            return errorMessageList;
        }
    }
}
