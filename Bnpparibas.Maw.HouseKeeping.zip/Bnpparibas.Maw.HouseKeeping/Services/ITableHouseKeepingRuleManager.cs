﻿using System.Collections.Generic;
using Bnpparibas.Maw.HouseKeeping.Entities;

namespace Bnpparibas.Maw.HouseKeeping.Services
{
    public interface ITableHouseKeepingRuleManager
    {
        IList<TableHouseKeepingRuleInstance> CreateRuleInstances(IList<TableHouseKeepingRule> houseKeepingRuleList, DbGraph dbGraph);
    }
}