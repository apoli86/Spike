﻿namespace Bnpparibas.Maw.HouseKeeping.Entities.HouseKeepingConfiguration
{
    public class AdditionalWhereCondition
    {
        public string Expression { get; set; }

    }
}
