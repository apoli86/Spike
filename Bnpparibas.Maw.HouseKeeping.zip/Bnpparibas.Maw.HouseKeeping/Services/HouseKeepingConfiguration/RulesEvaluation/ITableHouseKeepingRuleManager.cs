﻿using System.Collections.Generic;
using Bnpparibas.Maw.HouseKeeping.Entities.DbGraph;
using Bnpparibas.Maw.HouseKeeping.Entities.HouseKeepingConfiguration;

namespace Bnpparibas.Maw.HouseKeeping.Services.HouseKeepingConfiguration.RulesEvaluation
{
    public interface ITableHouseKeepingRuleManager
    {
        IList<TableHouseKeepingRuleInstance> CreateRuleInstanceList(IList<TableHouseKeepingRule> houseKeepingRuleList, DbGraph dbGraph);
    }
}