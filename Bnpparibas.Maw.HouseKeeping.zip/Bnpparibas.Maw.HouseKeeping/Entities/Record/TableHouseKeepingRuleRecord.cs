﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bnpparibas.Maw.HouseKeeping.Entities.Record
{
    public class TableHouseKeepingRuleRecord
    {
        public string TableSchema                    { get; set; }
        public string TableName                      { get; set; }
        public string DeleteWhereCondition           { get; set; }
        public string AdditionalDeleteWhereCondition { get; set; }
    }
}
