﻿using System;
using System.Collections.Generic;

namespace Bnpparibas.Maw.HouseKeeping.DAL
{
    public interface IContext : IDisposable
    {
        void Commit();
        long Execute(string sql, object param = null, int timeoutInSeconds = 60);
        T ExecuteScalar<T>(string sql, object param = null) where T : struct;
        IList<T> Query<T>(string sql, object param = null) where T : class;
        void Rollback();
    }
}