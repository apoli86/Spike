﻿using Bnpparibas.Maw.HouseKeeping.Entities;

namespace Bnpparibas.Maw.HouseKeeping.Services
{
    public interface IHouseKeepingConfigurationReader
    {
        HouseKeepingConfiguration Read(byte[] content);
    }
}