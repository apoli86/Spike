﻿using System.Collections.Generic;

namespace Bnpparibas.Maw.HouseKeeping.Entities.Record
{
    public class HouseKeepingConfigurationRecord
    {
        public List<TableHouseKeepingRuleRecord> Rules { get; set; }
    }
}
