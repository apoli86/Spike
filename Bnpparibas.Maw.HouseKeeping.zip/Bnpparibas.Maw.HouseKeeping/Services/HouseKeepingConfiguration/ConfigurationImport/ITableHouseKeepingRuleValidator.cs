﻿using System.Collections.Generic;
using Bnpparibas.Maw.HouseKeeping.Entities.HouseKeepingConfiguration;

namespace Bnpparibas.Maw.HouseKeeping.Services.HouseKeepingConfiguration.ConfigurationImport
{
    public interface ITableHouseKeepingRuleValidator
    {
        IList<string> Validate(TableHouseKeepingRule rule);
    }
}