﻿namespace Bnpparibas.Maw.HouseKeeping.Entities.DbGraph
{
    public class DbForeignKey
    {
        public DbTable ParentTable { get; set; }
        public DbTable ChildTable { get; set; }

        public string ForeignKeyName { get; set; }
    }
}
