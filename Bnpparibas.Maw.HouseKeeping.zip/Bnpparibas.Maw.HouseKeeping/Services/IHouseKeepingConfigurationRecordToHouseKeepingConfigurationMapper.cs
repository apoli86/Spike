﻿using Bnpparibas.Maw.HouseKeeping.Entities;
using Bnpparibas.Maw.HouseKeeping.Entities.Record;

namespace Bnpparibas.Maw.HouseKeeping.Services
{
    public interface IHouseKeepingConfigurationRecordToHouseKeepingConfigurationMapper
    {
        HouseKeepingConfiguration Map(HouseKeepingConfigurationRecord record);
    }
}