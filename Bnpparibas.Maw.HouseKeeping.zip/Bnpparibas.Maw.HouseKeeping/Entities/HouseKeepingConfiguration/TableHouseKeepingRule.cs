﻿namespace Bnpparibas.Maw.HouseKeeping.Entities.HouseKeepingConfiguration
{
    public class TableHouseKeepingRule
    {
        public string TableSchema { get; set; }
        public string TableName { get; set; }

        public WhereConditionOnTime WhereConditionOnTime { get; set; }
        public AdditionalWhereCondition AdditionalWhereCondition { get; set; }

        public bool IsValid { get; set; }
        public string ErrorMessage { get; set; }
    }
}
