﻿namespace Bnpparibas.Maw.HouseKeeping.Services.HouseKeepingConfiguration.ConfigurationImport
{
    public interface IHouseKeepingConfigurationReader
    {
        Entities.HouseKeepingConfiguration.HouseKeepingConfiguration Read(byte[] content);
    }
}