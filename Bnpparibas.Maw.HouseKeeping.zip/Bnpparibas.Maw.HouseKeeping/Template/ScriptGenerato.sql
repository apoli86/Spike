-- [dbo].[Order]

CREATE TABLE #TmpdboOrder (
    Id int PRIMARY KEY
)
GO

INSERT INTO #TmpdboOrder SELECT Id FROM [dbo].[Order] WHERE OrderDate < '2014-10-20' 
            
-- [dbo].[OrderItem]
SELECT COUNT(*) FROM [dbo].[OrderItem] dboOrderItem WITH(nolock) 
 INNER JOIN #TmpdboOrder dboOrder WITH(nolock) ON dboOrder.Id = dboOrderItem.OrderId 

-- [dbo].[OrderItem]

DECLARE @AffectedRow AS BIGINT = 1

WHILE (@AffectedRow > 0)
BEGIN
    DELETE TOP (100) dboOrderItem FROM [dbo].[OrderItem] dboOrderItem WITH(nolock) 
      INNER JOIN #TmpdboOrder dboOrder WITH(nolock) ON dboOrder.Id = dboOrderItem.OrderId 


    SET @AffectedRow = @@ROWCOUNT
END
GO

-- #TmpdboOrder
SELECT COUNT(*) FROM #TmpdboOrder dboOrder WITH(nolock)
-- [dbo].[Order]

DECLARE @AffectedRow AS BIGINT = 1

WHILE (@AffectedRow > 0)
BEGIN
    DELETE TOP (100) dboOrder FROM [dbo].[Order] dboOrder WITH(nolock) 
        INNER JOIN #TmpdboOrder TmpdboOrder WITH(nolock) ON TmpdboOrder.Id = dboOrder.Id

    SET @AffectedRow = @@ROWCOUNT

    DELETE TOP (100) TmpdboOrder FROM #TmpdboOrder TmpdboOrder WITH(nolock)
END
GO

-- [dbo].[Order]

DROP TABLE #TmpdboOrder
            
