﻿using Bnpparibas.Maw.HouseKeeping.Entities.HouseKeepingConfiguration.Record;

namespace Bnpparibas.Maw.HouseKeeping.Services.HouseKeepingConfiguration.ConfigurationImport
{
    public interface IHouseKeepingConfigurationRecordToHouseKeepingConfigurationMapper
    {
        Entities.HouseKeepingConfiguration.HouseKeepingConfiguration Map(HouseKeepingConfigurationRecord record);
    }
}