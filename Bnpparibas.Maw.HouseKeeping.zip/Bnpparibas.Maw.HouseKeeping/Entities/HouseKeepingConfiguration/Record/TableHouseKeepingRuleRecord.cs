﻿namespace Bnpparibas.Maw.HouseKeeping.Entities.HouseKeepingConfiguration.Record
{
    public class TableHouseKeepingRuleRecord
    {
        public string TableSchema                    { get; set; }
        public string TableName                      { get; set; }
        public string DeleteWhereCondition           { get; set; }
        public string AdditionalDeleteWhereCondition { get; set; }
    }
}
