﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using Dapper;

namespace Bnpparibas.Maw.HouseKeeping.DAL
{
    public class DapperContext : IContext
    {
        private readonly IDbConnection dbConnection;
        private readonly IDbTransaction dbTransaction;

        private bool errorOccured;

        public DapperContext(string connectionString)
        {
            if (connectionString == null) throw new ArgumentNullException(nameof(connectionString));

            dbConnection = new SqlConnection(connectionString);
            dbConnection.Open();

            dbTransaction = dbConnection.BeginTransaction();

            errorOccured = false;
        }

        public IList<T> Query<T>(string sql, object param = null) where T : class
        {
            if (sql == null) throw new ArgumentNullException(nameof(sql));

            try
            {
                return dbConnection.Query<T>(sql, param, dbTransaction).ToList();
            }
            catch(Exception)
            {
                errorOccured = true;
                throw;
            }
        }

        public T ExecuteScalar<T>(string sql, object param = null) where T : struct
        {
            if (sql == null) throw new ArgumentNullException(nameof(sql));

            try
            {
                return dbConnection.ExecuteScalar<T>(sql, param, dbTransaction);
            }
            catch (Exception)
            {
                errorOccured = true;
                throw;
            }
        }

        public long Execute(string sql, object param = null, int timeoutInSeconds = 30)
        {
            if (sql == null) throw new ArgumentNullException(nameof(sql));

            try
            {
                return dbConnection.Execute(sql, param, dbTransaction, timeoutInSeconds);
            }
            catch (Exception)
            {
                errorOccured = true;
                throw;
            }
        }

        public void Commit()
        {
            try
            {
                dbTransaction.Commit();
            }
            catch (Exception)
            {
                errorOccured = true;
                throw;
            }
        }

        public void Rollback()
        {
            try
            {
                dbTransaction.Rollback();
            }
            catch (Exception)
            {
                errorOccured = true;
                throw;
            }
        }

        public void Dispose()
        {
            if (errorOccured)
            {
                dbTransaction.Rollback();
            }
        }
    }
}
