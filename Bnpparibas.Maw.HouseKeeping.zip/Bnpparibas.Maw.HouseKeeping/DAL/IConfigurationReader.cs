﻿namespace Bnpparibas.Maw.HouseKeeping.DAL
{
    public interface IConfigurationReader
    {
        string ConnectionString { get; }
    }
}