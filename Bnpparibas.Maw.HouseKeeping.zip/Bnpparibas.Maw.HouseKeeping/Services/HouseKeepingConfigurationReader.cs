﻿using Bnpparibas.Maw.HouseKeeping.Entities;
using Bnpparibas.Maw.HouseKeeping.Entities.Record;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bnpparibas.Maw.HouseKeeping.Services
{
    public class HouseKeepingConfigurationReader : IHouseKeepingConfigurationReader
    {
        private readonly IHouseKeepingConfigurationRecordToHouseKeepingConfigurationMapper mapper;

        public HouseKeepingConfigurationReader(IHouseKeepingConfigurationRecordToHouseKeepingConfigurationMapper mapper)
        {
            if (mapper == null) throw new ArgumentNullException(nameof(mapper));

            this.mapper = mapper;
        }

        public HouseKeepingConfiguration Read(byte[] content)
        {
            if (content == null) throw new ArgumentNullException(nameof(content));

            using (StreamReader r = new StreamReader(new MemoryStream(content)))
            {
                string json = r.ReadToEnd();
                HouseKeepingConfigurationRecord record = JsonConvert.DeserializeObject<HouseKeepingConfigurationRecord>(json);

                return mapper.Map(record);
            }
        }
    }
}
