﻿using System.Collections.Generic;
using Bnpparibas.Maw.HouseKeeping.Entities.DbGraph.Dto;

namespace Bnpparibas.Maw.HouseKeeping.DAL
{
    public interface ISchemaDao
    {
        IList<DbForeignKeyDto> GetAllForeignKeyList(IContext context);
        IList<DbTableDto> GetAllTables(IContext context);
    }
}