﻿using Bnpparibas.Maw.HouseKeeping.DAL;
using Bnpparibas.Maw.HouseKeeping.Entities;
using Bnpparibas.Maw.HouseKeeping.Entities.Dto;
using Bnpparibas.Maw.HouseKeeping.Services;
using CommandLine;
using Microsoft.Practices.Unity;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bnpparibas.Maw.HouseKeeping
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                var unityContainer = (new UnityConfiguration()).BuildUnityContainer();

                CommandLineArgs commandLineArgs = ParseCommandLineArgs(args);

                IHouseKeepingProcess houseKeepingProcess = unityContainer.Resolve<IHouseKeepingProcess>();

                string houseKeepingConfigurationFile = commandLineArgs.HouseKeepingConfigurationFile;
                bool simulate = commandLineArgs.Simulate;
                int timeoutInSeconds = (int) TimeSpan.FromMinutes(commandLineArgs.TimeoutInMinutes).TotalSeconds;
                int rowCount = commandLineArgs.RowCount;

                houseKeepingProcess.RunHouseKeeping(
                    houseKeepingConfigurationFile,
                    simulate,
                    timeoutInSeconds,
                    rowCount);
            }
            catch(Exception e)
            {
                Console.WriteLine(e.Message);

                Environment.Exit(-1);
            }

            Console.ReadKey();
            Environment.Exit(0);
        }

        private static CommandLineArgs ParseCommandLineArgs(string[] args)
        {
            var parsedCmdArgs = Parser.Default.ParseArguments<CommandLineArgs>(args);

            parsedCmdArgs.WithNotParsed(errors => throw new InvalidOperationException(string.Join(";", errors)));

            CommandLineArgs commandLineArgs = parsedCmdArgs.MapResult(t => t, t => new CommandLineArgs());

            return commandLineArgs;
        }
    }
}
